﻿from PIL import Image
import pytesseract
import os

def extract_text_from_image(image_path):
    try:
        image = Image.open(image_path)
        return pytesseract.image_to_string(image, lang='rus+eng')
    except Exception as e:
        print(f"Ошибка при обработке изображения: {e}")
        return ""