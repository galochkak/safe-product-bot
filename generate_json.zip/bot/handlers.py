﻿# bot/handlers.py
from aiogram import Router, types
from aiogram.filters import Command
from aiogram import F
from aiogram.types import Message
from bot.database import banned_additives
from utils.ocr import extract_text_from_image
import os

router = Router()

# === Функция автоматического определения страны по языку ===
def get_country_by_language(language_code):
    country_map = {
        "ru": "Россия",
        "uk": "Украина",
        "be": "Беларусь",
        "en": "США",
        "es": "Испания",
        "de": "Германия",
        "fr": "Франция",
        "it": "Италия",
        "pl": "Польша",
        "tr": "Турция"
    }
    return country_map.get(language_code, "Россия")  # По умолчанию — Россия


# === Функции проверки состава ===

def check_composition(text):
    found_dangerous = []
    text_upper = text.replace('ё', 'е').replace('Ё', 'Е').upper()
    
    for code, info in banned_additives.items():
        if code in text_upper:
            found_dangerous.append({
                'code': code,
                'name': info['name_ru'],
                'status': info['status'],
                'description': info['description']
            })
    return found_dangerous


def check_composition_for_country(text, country):
    found_dangerous = []
    text_upper = text.replace('ё', 'е').replace('Ё', 'Е').upper()

    for code, info in banned_additives.items():
        if code in text_upper:
            banned_countries = info.get("banned_in", [])
            allowed_countries = info.get("allowed_in", [])

            if country in banned_countries:
                status = f"🚫 Запрещён в {country}"
            elif country in allowed_countries:
                status = f"✅ Разрешён в {country}"
            else:
                status = f"ℹ️ Неизвестен статус в {country}"

            found_dangerous.append({
                'code': code,
                'name': info['name_ru'],
                'description': info['description'],
                'country_status': status
            })

    return found_dangerous


def build_response(items, country=None):
    if not items:
        return "✅ Запрещённых или опасных добавок не найдено."

    result = ""
    if country:
        result += f"<b>⚠️ Для <i>{country}</i>:</b>\n\n"

    for item in items:
        result += (
            f"<b>{item['code']}</b> — {item['name']}\n"
            f"{item['country_status']}\n"
            f"Описание: {item['description']}\n\n"
        )
    return result


# === Обработчики команд ===

@router.message(Command("start", "help"))
async def send_welcome(message: Message):
    user_lang = message.from_user.language_code
    country = get_country_by_language(user_lang)

    await message.answer(
        f"Привет! Я помогу проверить состав продукта для <b>{country}</b>.\n"
        "Пришли мне фото или текст состава."
    )


@router.message(Command("for_russia"))
async def handle_for_russia(message: Message):
    dangerous = check_composition_for_country(message.text, country="Россия")
    response = build_response(dangerous, country="Россия")
    await message.answer(response, parse_mode="HTML")


@router.message(Command("for_eu"))
async def handle_for_eu(message: Message):
    dangerous = check_composition_for_country(message.text, country="ЕС")
    response = build_response(dangerous, country="ЕС")
    await message.answer(response, parse_mode="HTML")


@router.message(Command("for_usa"))
async def handle_for_usa(message: Message):
    dangerous = check_composition_for_country(message.text, country="США")
    response = build_response(dangerous, country="США")
    await message.answer(response, parse_mode="HTML")


# === Обработка фото ===

@router.message(F.photo)
async def handle_photo(message: types.Message):
    photo = message.photo[-1]
    file = await message.bot.get_file(photo.file_id)
    file_path = file.file_path
    file_name = f"photo_{message.from_user.id}.jpg"

    try:
        await message.bot.download_file(file_path, file_name)
        text = extract_text_from_image(file_name)

        if text.strip():
            await message.answer(f"Распознанный текст:\n<blockquote>{text}</blockquote>")
            user_lang = message.from_user.language_code
            country = get_country_by_language(user_lang)
            dangerous = check_composition_for_country(text, country=country)
            response = build_response(dangerous, country=country)
            await message.answer(response, parse_mode="HTML")
        else:
            await message.answer("Не удалось распознать текст на фото. Попробуйте другое изображение.")

    except Exception as e:
        await message.answer("Произошла ошибка при обработке изображения.")
        print(e)
    finally:
        if os.path.exists(file_name):
            os.remove(file_name)


# === Автоматическая проверка для пользователя ===

@router.message(F.text)
async def check_additives(message: types.Message):
    user_lang = message.from_user.language_code
    country = get_country_by_language(user_lang)

    dangerous = check_composition_for_country(message.text, country=country)
    response = build_response(dangerous, country=country)
    await message.answer(response, parse_mode="HTML")