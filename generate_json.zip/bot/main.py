﻿import asyncio
import os
from aiogram import Bot, Dispatcher
from bot.handlers import router
from dotenv import load_dotenv

load_dotenv()

async def main():
    token = os.getenv("BOT_TOKEN")
    if not token:
        print("❌ BOT_TOKEN не найден!")
        return

    bot = Bot(token=token)
    dp = Dispatcher()
    dp.include_router(router)
    print("✅ Бот запущен!")
    await dp.start_polling(bot)

if __name__ == '__main__':
    asyncio.run(main())