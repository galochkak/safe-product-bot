﻿import os
import json

# Путь к JSON-файлу
json_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), "data", "banned_additives.json")

# Загружаем базу из JSON
with open(json_path, "r", encoding="utf-8") as f:
    banned_additives = json.load(f)

# Выведем список всех Е-кодов
print("🔍 Загружены Е-коды:", list(banned_additives.keys()))